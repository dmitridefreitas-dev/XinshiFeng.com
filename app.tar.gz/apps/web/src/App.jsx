import React from 'react';
import { Route, Routes, BrowserRouter as Router, useLocation } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext.jsx';
import { ReadingModeProvider } from './contexts/ReadingModeContext.jsx';
import { Toaster } from './components/ui/toaster';
import { AnimatePresence } from 'framer-motion';
import ScrollToTop from './components/ScrollToTop';
import Header from './components/Header.jsx';
import Footer from './components/Footer.jsx';
import HomePage from './pages/HomePage.jsx';
import AboutPage from './pages/AboutPage.jsx';
import ProjectsPage from './pages/ProjectsPage.jsx';
import ContactPage from './pages/ContactPage.jsx';
import WavePageTransition from './components/WavePageTransition.jsx';
import ParticleBackground from './components/ParticleBackground.jsx';
import SkillCard from './components/SkillCard.jsx';
import SkillDetailModal from './components/SkillDetailModal.jsx';

const AnimatedRoutes = () => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route 
          path="/" 
          element={
            <WavePageTransition>
              <HomePage />
            </WavePageTransition>
          } 
        />
        <Route 
          path="/about" 
          element={
            <WavePageTransition>
              <AboutPage />
            </WavePageTransition>
          } 
        />
        <Route 
          path="/projects" 
          element={
            <ProjectsPage />
          } 
        />
        <Route 
          path="/contact" 
          element={
            <WavePageTransition>
              <ContactPage />
            </WavePageTransition>
          } 
        />
      </Routes>
    </AnimatePresence>
  );
};

function App() {
  return (
    <ThemeProvider>
      <ReadingModeProvider>
        <Router>
          <ScrollToTop />
          <ParticleBackground />
          <div className="flex flex-col min-h-screen relative z-10">
            <Header />
            <main className="flex-grow">
              <AnimatedRoutes />
            </main>
            <Footer />
            <Toaster />
          </div>
        </Router>
      </ReadingModeProvider>
    </ThemeProvider>
  );
}

export default App;