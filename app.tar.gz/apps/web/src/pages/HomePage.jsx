import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronLeft,
  ChevronRight,
  Code2,
  TrendingUp,
  Database,
  Calendar,
  MapPin,
  Briefcase,
  ArrowRight,
} from 'lucide-react';
import FinanceTicker from '@/components/FinanceTicker.jsx';
import ProjectCard from '@/components/ProjectCard.jsx';
import KPISection from '@/components/KPISection.jsx';
import SkillCard from '@/components/SkillCard.jsx';
import SkillDetailModal from '@/components/SkillDetailModal.jsx';
import { useReadingMode } from '@/contexts/ReadingModeContext.jsx';

const HomePage = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [selectedSkill, setSelectedSkill] = useState(null);
  const navigate = useNavigate();
  const { isTechnicalMode } = useReadingMode();

  const heroProjects = [
    {
      title: 'Institutional Data Integration Engine',
      description: 'Automated data pipeline reducing manual work.',
      technicalDescription: 'Python ETL pipeline integrating IBKR-Harmony APIs with 80% efficiency gain.',
      metric: '80% efficiency gain',
      image: 'https://images.unsplash.com/photo-1516383274235-5f42d6c6426d',
      alt: 'Financial data visualization with charts and graphs on multiple screens',
    },
    {
      title: 'Quantitative Trading Deck',
      description: 'Real-time crypto trading platform.',
      technicalDescription: 'Asyncio WebSocket client with VWAP-based mean reversion execution logic.',
      metric: 'Real-time execution',
      image: 'https://images.unsplash.com/photo-1578098576845-51e4ff4305d5',
      alt: 'Trading terminal displaying real-time cryptocurrency market data',
    },
    {
      title: 'Statistical Analysis of Short-Term Market Efficiency (PEAD)',
      description: 'Analysis of stock market reactions to earnings.',
      technicalDescription: 'Statistical arbitrage analysis of PEAD hypothesis yielding 10.9% significant Alpha.',
      metric: '10.9% significant Alpha',
      image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3',
      alt: 'Statistical analysis and market efficiency charts',
    },
    {
      title: 'Running Surface Biomechanics Analysis',
      description: 'Analysis of running performance on different surfaces.',
      technicalDescription: 'Linear mixed-effects modeling for multi-surface biomechanical variance analysis.',
      metric: 'Multi-surface comparison',
      image: 'https://images.unsplash.com/photo-1508387104394-d13e1b497f85',
      alt: 'Athlete running on a track',
    },
    {
      title: 'Institutional Trading Terminal',
      description: 'Professional trading platform with secure login.',
      technicalDescription: 'React/Node.js full-stack terminal with JWT-based stateless authentication.',
      metric: 'Enterprise-grade security',
      image: 'https://images.unsplash.com/photo-1620266757065-5814239881fd',
      alt: 'Professional trading terminal interface with multiple data streams',
    },
    {
      title: 'Predictive Housing Modeling',
      description: 'AI model to predict house prices accurately.',
      technicalDescription: 'Random Forest regressor achieving R² 0.816 and RMSE of $270K on Australian housing dataset.',
      metric: 'R² 0.816, RMSE $270K',
      image: 'https://images.unsplash.com/photo-1596774419796-0318e0ab4ba1',
      alt: 'Data science visualization showing housing price predictions and model accuracy',
    },
    {
      title: 'Climate Science Analysis',
      description: 'Study showing global warming trends over time.',
      technicalDescription: 'Fourier analysis and linear modeling quantifying a 0.13°C/decade warming trend.',
      metric: '71% variation explained',
      image: 'https://images.unsplash.com/photo-1624964569761-0f9e4b427e0b',
      alt: 'Climate data visualization showing temperature trends and statistical analysis',
    },
  ];

  const featuredProjects = [
    {
      id: 1,
      title: 'Institutional Data Integration',
      shortDescription: 'Built automated pipelines at Amphora.',
      technicalShortDescription: 'Python/Pandas ETL pipeline for institutional data.',
      techStack: ['Python', 'Pandas', 'REST API'],
      marketStats: { timeSpent: '180h', linesOfCode: '3.2k', libraries: 12 },
    },
    {
      id: 2,
      title: 'Quantitative Trading System',
      shortDescription: 'Real-time crypto trading platform.',
      technicalShortDescription: 'Asyncio WebSocket client with automated execution.',
      techStack: ['Python', 'Asyncio', 'WebSockets'],
      marketStats: { timeSpent: '240h', linesOfCode: '4.5k', libraries: 15 },
    },
    {
      id: 4,
      title: 'Predictive Housing Model',
      shortDescription: 'AI for predicting housing prices.',
      technicalShortDescription: 'Random Forest regressor with hyperparameter tuning.',
      techStack: ['Random Forest', 'Scikit-learn'],
      marketStats: { timeSpent: '90h', linesOfCode: '1.8k', libraries: 6 },
    },
    {
      id: 5,
      title: 'Climate Statistical Modeling',
      shortDescription: 'Analysis of global temperature trends.',
      technicalShortDescription: 'Fourier analysis and spatial statistical modeling.',
      techStack: ['R', 'Linear Models', 'Spatial Analysis'],
      marketStats: { timeSpent: '110h', linesOfCode: '2.1k', libraries: 8 },
    },
  ];

  const skillsData = [
    {
      name: 'Python',
      description: 'General-purpose programming language',
      technicalDescription: 'High-level, interpreted programming language with dynamic semantics and robust standard library.',
      usedFor: ['data analysis', 'machine learning', 'automation'],
      technicalUsedFor: ['ETL pipelines', 'algorithmic trading', 'statistical modeling'],
      keyFeatures: ['Pandas', 'NumPy', 'Scikit-learn'],
      technicalKeyFeatures: ['asyncio', 'multiprocessing', 'memory management']
    },
    {
      name: 'SQL',
      description: 'Language for managing databases',
      technicalDescription: 'Domain-specific language used in programming and designed for managing data held in a RDBMS.',
      usedFor: ['query, update, and analyze structured data'],
      technicalUsedFor: ['complex joins', 'window functions', 'query optimization'],
      keyFeatures: ['data extraction and manipulation'],
      technicalKeyFeatures: ['PostgreSQL', 'MySQL', 'indexing strategies']
    },
    {
      name: 'R Studio',
      description: 'Environment for R programming language',
      technicalDescription: 'Integrated development environment for R, a programming language for statistical computing and graphics.',
      usedFor: ['statistical analysis and visualization'],
      technicalUsedFor: ['linear mixed-effects modeling', 'spatial statistics', 'time series analysis'],
      keyFeatures: ['academic and research settings'],
      technicalKeyFeatures: ['ggplot2', 'dplyr', 'lme4']
    },
    {
      name: 'VSCode',
      description: 'Code editor with powerful extensions',
      technicalDescription: 'Source-code editor made by Microsoft with support for debugging, syntax highlighting, and version control.',
      usedFor: ['writing and debugging code'],
      technicalUsedFor: ['remote development', 'containerized environments', 'integrated terminal workflows'],
      keyFeatures: ['Python', 'R', 'SQL', 'and more'],
      technicalKeyFeatures: ['Jupyter integration', 'GitLens', 'Copilot']
    },
    {
      name: 'Matplotlib',
      description: 'Python library for creating charts',
      technicalDescription: 'Comprehensive library for creating static, animated, and interactive visualizations in Python.',
      usedFor: ['data visualization'],
      technicalUsedFor: ['publication-quality figures', 'custom plot architectures', 'financial charting'],
      keyFeatures: ['line plots', 'scatter plots', 'histograms'],
      technicalKeyFeatures: ['object-oriented API', 'pyplot interface', 'custom color maps']
    },
    {
      name: 'Seaborn',
      description: 'Python library built on Matplotlib',
      technicalDescription: 'Python data visualization library based on matplotlib that provides a high-level interface for drawing attractive statistical graphics.',
      usedFor: ['statistical visualizations easier'],
      technicalUsedFor: ['correlation matrices', 'regression fits', 'multi-plot grids'],
      keyFeatures: ['heatmaps', 'pair plots', 'distribution plots'],
      technicalKeyFeatures: ['FacetGrid', 'categorical estimation', 'theme management']
    },
    {
      name: 'Excel/VBA',
      description: 'Spreadsheet software with programming',
      technicalDescription: 'Industry-standard spreadsheet application augmented with Visual Basic for Applications for macro programming.',
      usedFor: ['data analysis', 'modeling', 'automation'],
      technicalUsedFor: ['financial modeling', 'legacy system integration', 'automated reporting'],
      keyFeatures: ['automates repetitive tasks'],
      technicalKeyFeatures: ['PivotTables', 'Power Query', 'COM add-ins']
    },
    {
      name: 'PowerBI',
      description: 'Business analytics tool from Microsoft',
      technicalDescription: 'Interactive data visualization software developed by Microsoft with primary focus on business intelligence.',
      usedFor: ['interactive dashboards'],
      technicalUsedFor: ['DAX measure creation', 'data modeling', 'enterprise reporting'],
      keyFeatures: ['connects to various data sources'],
      technicalKeyFeatures: ['Power Query M', 'Row-level security', 'API integration']
    },
    {
      name: 'Tableau',
      description: 'Data visualization platform',
      technicalDescription: 'Visual analytics platform transforming the way we use data to solve problems.',
      usedFor: ['interactive, shareable dashboards'],
      technicalUsedFor: ['LOD expressions', 'complex data blending', 'server deployment'],
      keyFeatures: ['Drag-and-drop interface'],
      technicalKeyFeatures: ['Tableau Prep', 'calculated fields', 'dashboard actions']
    },
    {
      name: 'Quantlib',
      description: 'Library for quantitative finance',
      technicalDescription: 'Free/open-source library for quantitative finance, offering tools for derivative pricing and risk management.',
      usedFor: ['pricing derivatives', 'risk analysis'],
      technicalUsedFor: ['yield curve bootstrapping', 'Monte Carlo simulations', 'option pricing models'],
      keyFeatures: ['Industry standard in finance'],
      technicalKeyFeatures: ['C++ core', 'Python SWIG wrappers', 'stochastic processes']
    },
    {
      name: 'MATLAB',
      description: 'Programming platform for engineers',
      technicalDescription: 'Proprietary multi-paradigm programming language and numeric computing environment.',
      usedFor: ['matrix operations', 'algorithms'],
      technicalUsedFor: ['signal processing', 'financial toolbox applications', 'econometrics'],
      keyFeatures: ['academic research'],
      technicalKeyFeatures: ['Simulink', 'vectorized operations', 'toolboxes']
    },
    {
      name: 'Bloomberg',
      description: 'Financial data terminal',
      technicalDescription: 'Computer software system providing real-time financial market data, news, and analytics.',
      usedFor: ['Real-time market data', 'news', 'analytics'],
      technicalUsedFor: ['BQL queries', 'API data extraction', 'portfolio analytics'],
      keyFeatures: ['Industry standard in finance'],
      technicalKeyFeatures: ['Bloomberg API (B-PIPE)', 'Excel Add-in', 'Launchpad']
    },
    {
      name: 'FRED',
      description: 'Federal Reserve Economic Data',
      technicalDescription: 'Database maintained by the Research division of the Federal Reserve Bank of St. Louis.',
      usedFor: ['Free economic data'],
      technicalUsedFor: ['macroeconomic modeling', 'time series forecasting', 'API integration'],
      keyFeatures: ['Thousands of US and international datasets'],
      technicalKeyFeatures: ['FRED API', 'vintage data (ALFRED)', 'data transformations']
    },
    {
      name: 'Git',
      description: 'Version control system',
      technicalDescription: 'Distributed version control system tracking changes in any set of computer files.',
      usedFor: ['Tracks code changes over time'],
      technicalUsedFor: ['branching strategies', 'merge conflict resolution', 'CI/CD pipelines'],
      keyFeatures: ['collaboration'],
      technicalKeyFeatures: ['GitHub Actions', 'rebase', 'submodules']
    }
  ];

  const competencies = [
    {
      icon: TrendingUp,
      title: 'Quantitative Modeling',
      description: 'Statistical analysis, machine learning, and predictive modeling for financial markets',
    },
    {
      icon: Code2,
      title: 'Algorithmic Trading',
      description: 'Real-time trading systems, WebSocket integration, and automated execution strategies',
    },
    {
      icon: Database,
      title: 'Data Engineering',
      description: 'ETL pipelines, data integration, and automated processing workflows',
    },
  ];

  const timeline = [
    {
      year: '2024 - 2026',
      title: 'Washington University in St. Louis',
      description: 'BS Data Science and Financial Engineering (GPA: 3.7)',
      type: 'education',
    },
    {
      year: '2021 - 2023',
      title: 'Drew University',
      description: 'BA Mathematics (GPA: 3.7)',
      type: 'education',
    },
    {
      year: '2015 - 2021',
      title: 'Harrison College',
      description: 'A-level Examinations Unit I & II (GRADE: I AAA, with distinctions)',
      type: 'education',
    },
    {
      year: '2025',
      title: 'Amphora Investment Management',
      description: 'Intern - Built automated data pipelines reducing manual processing by 80%',
      type: 'experience',
    },
  ];

  const targetRoles = [
    'Quantitative Research Analyst',
    'Financial Engineer',
    'Data Scientist',
  ];

  useEffect(() => {
    if (!isPaused) {
      const interval = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % heroProjects.length);
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [isPaused, heroProjects.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % heroProjects.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + heroProjects.length) % heroProjects.length);
  };

  const handleViewProject = () => {
    navigate('/projects');
  };

  const handleSkillClick = (skill) => {
    setSelectedSkill(skill);
  };

  return (
    <>
      <Helmet>
        <title>Dmitri De Freitas - Quantitative Finance & Data Science Portfolio</title>
        <meta
          name="description"
          content="Portfolio of Dmitri De Freitas, specializing in quantitative finance, algorithmic trading, and data science. Available May 2026 for full-time opportunities."
        />
      </Helmet>

      <div className="min-h-screen">
        {/* Hero Carousel */}
        <section
          className="relative h-[600px] md:h-[700px] overflow-hidden"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.7 }}
              className="absolute inset-0"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-background/60 z-10" />
              <img
                src={heroProjects[currentSlide].image}
                alt={heroProjects[currentSlide].alt}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 z-20 flex items-center">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2, duration: 0.6 }}
                    className="max-w-2xl"
                  >
                    <Badge className="mb-4 bg-primary text-primary-foreground">
                      Available May 2026
                    </Badge>
                    <h1 className="text-4xl md:text-6xl font-bold mb-4 text-foreground">
                      {heroProjects[currentSlide].title}
                    </h1>
                    <p className="text-xl md:text-2xl mb-4 text-muted-foreground">
                      {isTechnicalMode 
                        ? heroProjects[currentSlide].technicalDescription 
                        : heroProjects[currentSlide].description}
                    </p>
                    <p className="text-lg md:text-xl font-semibold mb-6 text-primary">
                      {heroProjects[currentSlide].metric}
                    </p>
                    <Link to="/projects">
                      <Button size="lg" className="group">
                        View Project
                        <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </Link>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation Arrows */}
          <button
            onClick={prevSlide}
            className="absolute left-4 top-1/2 -translate-y-1/2 z-30 bg-background/80 hover:bg-background p-2 rounded-full transition-colors"
            aria-label="Previous slide"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-background/80 hover:bg-background p-2 rounded-full transition-colors"
            aria-label="Next slide"
          >
            <ChevronRight className="h-6 w-6" />
          </button>

          {/* Slide Indicators */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-30 flex space-x-2">
            {heroProjects.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentSlide ? 'bg-primary w-8' : 'bg-muted-foreground/50'
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </section>

        {/* Finance Ticker */}
        <FinanceTicker />

        {/* KPI Section */}
        <KPISection />

        {/* Featured Projects */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Featured Projects</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
                {featuredProjects.map((project, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1, duration: 0.6 }}
                    className="h-full"
                  >
                    <ProjectCard project={project} onViewProject={handleViewProject} />
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Technical Expertise */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Technical Expertise</h2>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  A comprehensive toolkit spanning programming languages, data visualization, and quantitative finance platforms.
                  Click on any skill to learn more about how I use it.
                </p>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {skillsData.map((skill, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.05, duration: 0.4 }}
                    className="group"
                  >
                    <SkillCard skill={skill} onClick={handleSkillClick} />
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Core Competencies */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Core Competencies</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {competencies.map((competency, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.2, duration: 0.6 }}
                  >
                    <Card className="h-full hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <competency.icon className="h-12 w-12 text-primary mb-4" />
                        <CardTitle>{competency.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">{competency.description}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* My Journey Timeline */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">My Journey</h2>
              <div className="max-w-3xl mx-auto space-y-8">
                {timeline.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.2, duration: 0.6 }}
                    className="flex gap-6"
                  >
                    <div className="flex flex-col items-center">
                      <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center shrink-0">
                        {item.type === 'education' ? (
                          <Calendar className="h-6 w-6 text-primary-foreground" />
                        ) : (
                          <Briefcase className="h-6 w-6 text-primary-foreground" />
                        )}
                      </div>
                      {index < timeline.length - 1 && (
                        <div className="w-0.5 h-full bg-border mt-2" />
                      )}
                    </div>
                    <Card className="flex-1">
                      <CardHeader>
                        <Badge variant="outline" className="w-fit mb-2">
                          {item.year}
                        </Badge>
                        <CardTitle className="text-xl">{item.title}</CardTitle>
                        <CardDescription>{item.description}</CardDescription>
                      </CardHeader>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Open to Opportunities */}
        <section className="py-16 bg-primary/5">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Open to Opportunities</h2>
              <p className="text-xl text-muted-foreground mb-8">
                Seeking full-time positions starting May 2026 in:
              </p>
              <div className="flex flex-wrap justify-center gap-4 mb-8">
                {targetRoles.map((role, index) => (
                  <Badge key={index} variant="secondary" className="text-base px-4 py-2">
                    {role}
                  </Badge>
                ))}
              </div>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-muted-foreground">
                <div className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  <span>St. Louis through May 2026</span>
                </div>
                <span className="hidden sm:inline">•</span>
                <span>Open to relocation</span>
              </div>
              <Link to="/contact" className="inline-block mt-8">
                <Button size="lg">
                  Get in Touch
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>

        {/* Gallery Preview */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Explore All Projects</h2>
              <p className="text-xl text-muted-foreground mb-8">
                Dive deeper into my portfolio of quantitative finance and data science projects
              </p>
              <Link to="/projects">
                <Button size="lg" variant="outline">
                  View All Projects
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>
      </div>

      <SkillDetailModal 
        isOpen={!!selectedSkill} 
        onClose={() => setSelectedSkill(null)} 
        skill={selectedSkill} 
      />
    </>
  );
};

export default HomePage;