import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { Download, GraduationCap, Briefcase, Target, MapPin, TrendingUp, Award } from 'lucide-react';
import AboutPageKPISection from '@/components/AboutPageKPISection.jsx';
import ExperienceCard from '@/components/ExperienceCard.jsx';
import ExperienceModal from '@/components/ExperienceModal.jsx';

const AboutPage = () => {
  const [selectedExperience, setSelectedExperience] = useState(null);

  const skillCategories = [
    {
      title: 'Programming & Languages',
      skills: [
        { name: 'Python', proficiency: 95 },
        { name: 'R', proficiency: 90 },
        { name: 'SQL', proficiency: 85 },
        { name: 'MATLAB', proficiency: 80 },
        { name: 'VBA', proficiency: 75 },
        { name: 'Bash', proficiency: 70 }
      ]
    },
    {
      title: 'Data Science & ML',
      skills: [
        { name: 'Pandas', proficiency: 95 },
        { name: 'NumPy', proficiency: 90 },
        { name: 'Scikit-learn', proficiency: 85 },
        { name: 'PyTorch', proficiency: 75 },
        { name: 'TensorFlow', proficiency: 70 },
        { name: 'Statsmodels', proficiency: 85 },
        { name: 'SciPy', proficiency: 80 }
      ]
    },
    {
      title: 'Data Visualization & BI',
      skills: [
        { name: 'Matplotlib', proficiency: 90 },
        { name: 'Seaborn', proficiency: 85 },
        { name: 'Plotly', proficiency: 80 },
        { name: 'Power BI', proficiency: 85 },
        { name: 'Tableau', proficiency: 80 }
      ]
    },
    {
      title: 'Databases & Big Data',
      skills: [
        { name: 'PostgreSQL', proficiency: 85 },
        { name: 'MySQL', proficiency: 80 },
        { name: 'MongoDB', proficiency: 75 },
        { name: 'AWS S3/EC2/Lambda', proficiency: 70 },
        { name: 'Apache Spark', proficiency: 65 }
      ]
    },
    {
      title: 'Quantitative & Finance',
      skills: [
        { name: 'Bloomberg Terminal', proficiency: 85 },
        { name: 'FRED', proficiency: 90 },
        { name: 'QuantLib', proficiency: 75 },
        { name: 'Backtrader', proficiency: 80 },
        { name: 'Interactive Brokers API', proficiency: 85 }
      ]
    },
    {
      title: 'Development & DevOps',
      skills: [
        { name: 'Git', proficiency: 90 },
        { name: 'GitHub', proficiency: 90 },
        { name: 'VS Code', proficiency: 95 },
        { name: 'Docker', proficiency: 75 },
        { name: 'Jupyter', proficiency: 95 },
        { name: 'Linux/Unix', proficiency: 80 }
      ]
    },
    {
      title: 'Cloud & Infrastructure',
      skills: [
        { name: 'AWS', proficiency: 75 },
        { name: 'Google Cloud', proficiency: 65 },
        { name: 'Azure', proficiency: 60 },
        { name: 'REST APIs', proficiency: 85 },
        { name: 'WebSockets', proficiency: 80 }
      ]
    }
  ];

  const targetRoles = [
    'Quantitative Research Analyst',
    'Financial Engineer',
    'Data Scientist',
    'Algorithmic Trading Developer',
  ];

  const experiences = [
    {
      title: 'Amphora Investment Management',
      organization: 'Intern',
      role: 'Data Scientist',
      date: '2025',
      shortDescription: 'Built automated data pipelines to speed up investment workflows.',
      technicalShortDescription: 'Architected Python-based ETL pipelines for IBKR-Harmony integration, reducing manual processing by 80%.',
      description: [
        'Reduced manual data processing by 80% with automated Python pipeline for IBKR-Harmony',
        'Sped up portfolio construction through quantitative models',
        'Streamlined deal-sourcing workflow with dynamic Excel tools',
        'Initiated automated investor reporting for performance attribution'
      ],
      technicalDescription: [
        'Engineered robust Python ETL pipelines integrating Interactive Brokers (IBKR) and Harmony APIs, achieving an 80% reduction in manual data reconciliation.',
        'Developed quantitative portfolio construction models utilizing Pandas and NumPy for optimized asset allocation.',
        'Architected dynamic VBA/Excel tools to streamline deal-sourcing workflows and enhance data visibility.',
        'Implemented automated performance attribution reporting systems for institutional investors.'
      ]
    },
    {
      title: 'Gary M. Sumers Recreation Center',
      organization: 'Washington University in St. Louis',
      role: 'Front Desk/Reception',
      date: '2025',
      shortDescription: 'Managed front desk operations and customer service.',
      technicalShortDescription: 'Managed facility access control systems and point-of-sale transaction processing.',
      description: [
        'Served as the primary point of contact for students, faculty, and guests, ensuring a welcoming and organized environment.',
        'Managed memberships, facility access, and point-of-sale transactions efficiently.',
        'Developed strong communication and problem-solving skills by addressing patron inquiries and resolving issues promptly.'
      ],
      technicalDescription: [
        'Operated facility access control systems and managed high-volume point-of-sale transaction processing.',
        'Maintained accurate membership databases and resolved access discrepancies in real-time.',
        'Optimized front-desk operational workflows to handle peak traffic periods efficiently.'
      ]
    },
    {
      title: 'Personal Care Assistant',
      organization: 'Private In-Home Care | SMA Patient',
      role: 'Caregiver',
      date: '2025-2026',
      shortDescription: 'Provided dedicated in-home care and daily assistance.',
      technicalShortDescription: 'Administered specialized medical equipment and monitored patient health metrics.',
      description: [
        'Delivered dedicated in-home care and daily living assistance for a patient with Spinal Muscular Atrophy (SMA).',
        'Assisted with mobility, personal hygiene, and specialized equipment operation.',
        'Monitored health status and maintained a safe, supportive environment, demonstrating high reliability and empathy.'
      ],
      technicalDescription: [
        'Administered and maintained specialized medical equipment for a patient with Spinal Muscular Atrophy (SMA).',
        'Monitored critical health metrics and executed emergency protocols when necessary.',
        'Maintained detailed health logs and coordinated with medical professionals to ensure optimal care delivery.'
      ]
    },
    {
      title: "Duke of Edinburgh's International",
      organization: 'Expedition',
      role: 'Bronze Award',
      date: '2021',
      shortDescription: 'Completed rigorous outdoor expedition and teamwork challenges.',
      technicalShortDescription: 'Executed complex route planning and resource management under demanding environmental constraints.',
      description: [
        'Successfully completed the rigorous expedition component, demonstrating physical endurance and outdoor survival skills.',
        'Collaborated with a team to plan routes, manage resources, and navigate challenging terrain.',
        'Developed strong leadership, teamwork, and resilience under demanding conditions.'
      ],
      technicalDescription: [
        'Executed complex topographical route planning and navigation using traditional orienteering methods.',
        'Managed critical resource allocation (water, rations, medical supplies) under demanding environmental constraints.',
        'Demonstrated crisis management and team leadership during high-stress expedition scenarios.'
      ]
    },
    {
      title: 'Science Club President',
      organization: 'Harrison College',
      role: 'President',
      date: '2020-2021',
      shortDescription: 'Led student science club and organized educational events.',
      technicalShortDescription: 'Directed STEM initiatives and coordinated experimental demonstrations for junior members.',
      description: [
        "Led the school's Science Club, organizing educational events, experiments, and competitions to foster STEM interest.",
        'Coordinated weekly meetings and managed a team of student volunteers to execute club initiatives.',
        'Enhanced public speaking and organizational skills while mentoring junior members in scientific concepts.'
      ],
      technicalDescription: [
        'Directed STEM curriculum development and coordinated complex experimental demonstrations.',
        'Managed club budget, resource procurement, and logistical planning for inter-school competitions.',
        'Implemented structured mentorship programs to improve junior members\' scientific literacy and analytical skills.'
      ]
    },
    {
      title: 'Startup Founder & Manager',
      organization: 'MobileHub Barbados',
      role: 'Founder',
      date: '2022-2024',
      shortDescription: 'Founded and managed a mobile technology business.',
      technicalShortDescription: 'Engineered supply chain logistics and managed international vendor API integrations.',
      description: [
        'Founded and scaled a mobile technology startup, overseeing all aspects of business operations and strategy.',
        'Managed international vendor relations and supply chain logistics in partnership with Shenzhen Rongyi Technology Co., Ltd.',
        'Handled inventory management, customer service, and financial tracking to ensure profitability and growth.'
      ],
      technicalDescription: [
        'Engineered end-to-end supply chain logistics and managed international vendor relations with Shenzhen Rongyi Technology Co., Ltd.',
        'Implemented inventory tracking systems and financial modeling to optimize cash flow and profitability.',
        'Developed and executed go-to-market strategies, achieving consistent month-over-month revenue growth.'
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>About - Dmitri De Freitas</title>
        <meta
          name="description"
          content="Learn about Dmitri De Freitas's background in quantitative finance and data science, education at Washington University in St. Louis, and professional experience."
        />
      </Helmet>

      <div className="min-h-screen pt-20">
        {/* Hero Section with Headshot */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto text-center"
            >
              <div className="relative w-40 h-40 mx-auto mb-6">
                <div className="w-full h-full rounded-full border-4 border-primary shadow-xl overflow-hidden relative">
                  <img
                    src="https://horizons-cdn.hostinger.com/21974f96-abad-40ec-bff7-0adadb1dfab0/f4feb6c64fe322280c7ed8d4608b1f8a.png"
                    alt="Dmitri De Freitas professional headshot"
                    className="w-full h-full object-cover object-top scale-[1.35] translate-y-2"
                  />
                </div>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4">About Me</h1>
              <Badge className="mb-6 bg-primary text-primary-foreground">
                Available May 2026
              </Badge>
            </motion.div>
          </div>
        </section>

        {/* Background Story */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto"
            >
              <h2 className="text-3xl font-bold mb-6">My Story</h2>
              <div className="prose prose-lg max-w-none text-muted-foreground">
                <p className="mb-4">
                  My fascination with markets began not just with price movements, but with the underlying data patterns that drive them. This curiosity led me to pursue dual expertise in Data Science and Financial Engineering at Washington University in St. Louis.
                </p>
                <p className="mb-4">
                  Throughout my academic journey, I've developed a unique blend of quantitative rigor and practical implementation skills. From building automated data pipelines that process thousands of institutional records to developing real-time trading systems, I thrive at the intersection of finance, mathematics, and technology.
                </p>
                <p>
                  What drives me is the challenge of transforming complex financial problems into elegant, data-driven solutions. Whether it's predicting housing prices with machine learning or analyzing climate patterns with statistical models, I approach each project with the same commitment to precision and insight.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Education Section */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto"
            >
              <div className="flex items-center gap-3 mb-8 justify-center">
                <GraduationCap className="h-8 w-8 text-primary" />
                <h2 className="text-3xl font-bold">Education</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                {/* Left Column */}
                <div className="flex flex-col gap-4">
                  <Card className="p-4">
                    <h3 className="font-bold text-base leading-tight mb-1">Washington University in St. Louis</h3>
                    <p className="text-sm text-muted-foreground mb-3">BS Data Science and Financial Engineering</p>
                    <div className="flex flex-col gap-2 items-start">
                      <Badge variant="outline" className="text-xs">2024-2026</Badge>
                      <Badge variant="secondary" className="text-xs">GPA: 3.7</Badge>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <h3 className="font-bold text-base leading-tight mb-1">Drew University</h3>
                    <p className="text-sm text-muted-foreground mb-3">BA Mathematics</p>
                    <div className="flex flex-col gap-2 items-start">
                      <Badge variant="outline" className="text-xs">2021-2023</Badge>
                      <Badge variant="secondary" className="text-xs">GPA: 3.7</Badge>
                    </div>
                  </Card>
                </div>

                {/* Right Column */}
                <div className="flex flex-col gap-4">
                  <Card className="p-4">
                    <h3 className="font-bold text-base leading-tight mb-1">Harrison College</h3>
                    <p className="text-sm text-muted-foreground mb-3">A-level Examinations Unit I & II</p>
                    <div className="flex flex-col gap-2 items-start">
                      <Badge variant="outline" className="text-xs">2020-2021</Badge>
                      <Badge variant="secondary" className="text-xs">GRADE: I AAA</Badge>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <h3 className="font-bold text-base leading-tight mb-1">Caribbean Examinations Council</h3>
                    <p className="text-sm text-muted-foreground mb-3">CAPE® Unit II</p>
                    <div className="flex flex-col gap-2 items-start">
                      <Badge variant="outline" className="text-xs">2021</Badge>
                      <Badge className="bg-amber-500/10 text-amber-600 hover:bg-amber-500/20 border-amber-500/30 flex items-center gap-1 text-xs w-fit">
                        <Award className="w-3 h-3" />
                        TOP 8 candidate Physics Unit II with Honors
                      </Badge>
                    </div>
                  </Card>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Experience Section */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-5xl mx-auto"
            >
              <div className="flex items-center gap-3 mb-8 justify-center">
                <Briefcase className="h-8 w-8 text-primary" />
                <h2 className="text-3xl font-bold">Experience</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {experiences.map((exp, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                  >
                    <ExperienceCard 
                      experience={exp} 
                      onClick={(exp) => setSelectedExperience(exp)} 
                    />
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Target Roles & Availability */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <Target className="h-10 w-10 text-primary mb-4" />
                    <CardTitle>Target Roles</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {targetRoles.map((role, index) => (
                        <li key={index} className="flex items-start">
                          <span className="text-primary mr-2">•</span>
                          <span className="text-muted-foreground">{role}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <MapPin className="h-10 w-10 text-primary mb-4" />
                    <CardTitle>Availability</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">
                      Open to full-time opportunities starting May 2026
                    </p>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4 text-primary" />
                        <span>Currently in St. Louis</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <TrendingUp className="h-4 w-4 text-primary" />
                        <span>Willing to relocate</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Distinct About Page KPI Section */}
        <AboutPageKPISection />

        {/* Technical Skills - Refined */}
        <section className="py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-5xl mx-auto"
            >
              <h2 className="text-3xl font-bold mb-12 text-center">Technical Skills</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {skillCategories.map((category, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    whileHover={{ y: -5 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1, duration: 0.4 }}
                    className="h-full"
                  >
                    <Card className="h-full border-border/50 shadow-md hover:shadow-xl transition-all duration-300">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base font-semibold text-primary/90 uppercase tracking-wider">
                          {category.title}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-x-6 gap-y-4">
                          {category.skills.map((skill, idx) => (
                            <div key={idx} className="flex items-center gap-3">
                              <div className="flex-1 space-y-1.5">
                                <div className="flex justify-between text-xs">
                                  <span className="font-medium text-foreground/80">{skill.name}</span>
                                </div>
                                <div className="w-full bg-muted rounded-full h-1.5 overflow-hidden">
                                  <motion.div
                                    initial={{ width: 0 }}
                                    whileInView={{ width: `${skill.proficiency}%` }}
                                    viewport={{ once: true }}
                                    transition={{ delay: idx * 0.05 + 0.2, duration: 0.8, ease: "easeOut" }}
                                    className="bg-primary/80 h-full rounded-full"
                                  />
                                </div>
                              </div>
                              <span className="text-xs font-mono font-medium text-primary w-6 text-right">
                                {skill.proficiency}
                              </span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Professional Philosophy */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto"
            >
              <Card className="bg-primary/5 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-2xl">Professional Philosophy</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed">
                    I believe that the most powerful insights emerge at the intersection of rigorous quantitative analysis and practical implementation. Every line of code I write, every model I build, is driven by a commitment to precision, clarity, and real-world impact. In an industry where milliseconds and basis points matter, I bring both the technical expertise and the analytical mindset to deliver solutions that don't just work—they excel.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-primary/5">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-2xl mx-auto text-center"
            >
              <h2 className="text-3xl font-bold mb-6">Let's Connect</h2>
              <p className="text-muted-foreground mb-8">
                Interested in learning more about my work or discussing opportunities? Download my resume or get in touch.
              </p>
              <Button asChild size="lg">
                <a href="https://drive.google.com/file/d/1Ff9CtgP3OndC67ARXolrRjH6Y2seE1Sl/view?usp=drive_link" target="_blank" rel="noopener noreferrer">
                  <Download className="mr-2 h-5 w-5" />
                  Download Resume
                </a>
              </Button>
            </motion.div>
          </div>
        </section>
      </div>

      <ExperienceModal 
        isOpen={!!selectedExperience} 
        onClose={() => setSelectedExperience(null)} 
        experience={selectedExperience} 
      />
    </>
  );
};

export default AboutPage;