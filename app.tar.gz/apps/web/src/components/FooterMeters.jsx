import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';

const FooterMeters = () => {
  const [alpha, setAlpha] = useState(100);
  const [signal, setSignal] = useState(90);

  useEffect(() => {
    // Alpha drops from 100 to 95 over ~5 minutes (300,000ms)
    // Drop 0.01 every 600ms
    const alphaInterval = setInterval(() => {
      setAlpha((prev) => {
        const next = prev - 0.01;
        return next < 95 ? 95 : next;
      });
    }, 600);

    // Signal fluctuates between 85 and 95 every 2.5s
    const signalInterval = setInterval(() => {
      setSignal(85 + Math.random() * 10);
    }, 2500);

    return () => {
      clearInterval(alphaInterval);
      clearInterval(signalInterval);
    };
  }, []);

  return (
    <div className="flex flex-wrap items-center justify-center md:justify-end gap-6 text-xs font-mono text-muted-foreground">
      {/* Alpha Remaining */}
      <div className="flex items-center gap-2">
        <span>Alpha Remaining:</span>
        <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-primary"
            initial={{ width: '100%' }}
            animate={{ width: `${alpha}%` }}
            transition={{ duration: 0.6, ease: "linear" }}
          />
        </div>
        <span className="w-10 text-right">{alpha.toFixed(2)}%</span>
      </div>

      {/* Signal Strength */}
      <div className="flex items-center gap-2">
        <span>Signal Strength:</span>
        <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-accent"
            animate={{ width: `${signal}%` }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
          />
        </div>
        <span className="w-10 text-right">{signal.toFixed(1)}%</span>
      </div>

      {/* Statistical Significance */}
      <div className="flex items-center gap-1.5">
        <span>p &lt; 0.05</span>
        <motion.div
          initial={{ scale: 0.8, opacity: 0.5 }}
          animate={{ scale: [0.8, 1.1, 1], opacity: [0.5, 1, 0.8] }}
          transition={{ duration: 2, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }}
        >
          <CheckCircle2 className="h-3.5 w-3.5 text-primary" />
        </motion.div>
      </div>
    </div>
  );
};

export default FooterMeters;