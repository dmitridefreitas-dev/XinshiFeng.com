import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { useReadingMode } from '@/contexts/ReadingModeContext.jsx';

const ProjectCard = ({ project, onViewProject }) => {
  const { isTechnicalMode } = useReadingMode();
  
  const displayDescription = isTechnicalMode && project.technicalShortDescription 
    ? project.technicalShortDescription 
    : project.shortDescription;

  return (
    <motion.div
      whileHover={{ 
        y: -5, 
        boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)" 
      }}
      transition={{ duration: 0.2, ease: "easeOut" }}
      className="h-full rounded-xl cursor-pointer group"
      onClick={() => onViewProject(project)}
    >
      <Card className="h-full flex flex-col overflow-hidden border-border/50 hover:border-primary/50 transition-colors duration-300">
        <CardHeader className="p-5 pb-2">
          <div className="h-6 flex flex-wrap gap-1.5 mb-2 overflow-hidden">
            {project.techStack.slice(0, 3).map((tech, index) => (
              <Badge key={index} variant="secondary" className="text-[10px] px-1.5 py-0 h-5 flex items-center">
                {tech}
              </Badge>
            ))}
            {project.techStack.length > 3 && (
              <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-5 flex items-center">
                +{project.techStack.length - 3} more
              </Badge>
            )}
          </div>
          <div className="h-12 flex items-center mb-0.5">
            <CardTitle className="text-lg font-bold leading-tight line-clamp-2 group-hover:text-primary transition-colors">{project.title}</CardTitle>
          </div>
          <div className="h-10 flex items-start">
            <CardDescription className="text-sm line-clamp-2">
              {displayDescription}
            </CardDescription>
          </div>
        </CardHeader>
        
        <CardContent className="flex-grow p-5 pt-0 flex flex-col justify-end">
          <p className="text-xs text-muted-foreground/60 group-hover:text-primary/80 transition-colors flex items-center gap-1 mt-4">
            Click for details
            <motion.span
              initial={{ x: 0 }}
              whileHover={{ x: 4 }}
              className="inline-block"
            >→</motion.span>
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProjectCard;