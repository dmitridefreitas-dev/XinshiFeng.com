import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Github } from 'lucide-react';
import { useReadingMode } from '@/contexts/ReadingModeContext.jsx';

const ProjectDetailModal = ({ project, isOpen, onClose }) => {
  const { isTechnicalMode } = useReadingMode();

  if (!project) return null;

  const hasCodeLink = project.codeLink && project.codeLink !== '#';
  
  const displayDescription = isTechnicalMode && project.technicalDescription 
    ? project.technicalDescription 
    : (project.simpleDescription || project.fullDescription);

  const displayShortDescription = isTechnicalMode && project.technicalShortDescription
    ? project.technicalShortDescription
    : project.shortDescription;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">{project.title}</DialogTitle>
          <DialogDescription className="text-base mt-2">
            {displayShortDescription}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div>
            <h3 className="text-lg font-semibold mb-3">Tech Stack</h3>
            <div className="flex flex-wrap gap-2">
              {project.techStack.map((tech, index) => (
                <Badge key={index} variant="secondary">
                  {tech}
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-3">
              {isTechnicalMode ? 'Technical Implementation Details' : 'Project Overview'}
            </h3>
            <p className="text-muted-foreground leading-relaxed">
              {displayDescription}
            </p>
          </div>

          {project.metrics && project.metrics.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-3">Key Metrics & Outcomes</h3>
              <ul className="space-y-2">
                {project.metrics.map((metric, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-primary mr-2">•</span>
                    <span className="text-muted-foreground">{metric}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <DialogFooter className="flex-col sm:flex-row gap-3 mt-6">
          {project.reportLink && project.reportLink !== '#' && (
            <Button
              variant="outline"
              onClick={() => window.open(project.reportLink, '_blank')}
              className="w-full sm:w-auto"
            >
              <FileText className="mr-2 h-4 w-4" />
              View Report
            </Button>
          )}
          {hasCodeLink && (
            <Button
              onClick={() => window.open(project.codeLink, '_blank')}
              className="w-full sm:w-auto"
            >
              <Github className="mr-2 h-4 w-4" />
              View Code
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ProjectDetailModal;