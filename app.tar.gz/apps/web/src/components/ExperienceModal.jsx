import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { useReadingMode } from '@/contexts/ReadingModeContext.jsx';

const ExperienceModal = ({ isOpen, onClose, experience }) => {
  const { isTechnicalMode } = useReadingMode();

  if (!experience) return null;

  const rawDetails = isTechnicalMode && experience.technicalDescription 
    ? experience.technicalDescription 
    : experience.description;
    
  const details = Array.isArray(rawDetails) ? rawDetails : [rawDetails];

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto bg-card">
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="p-2 sm:p-4"
            >
              <DialogHeader className="mb-6">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4 mb-2">
                  <DialogTitle className="text-2xl font-bold leading-tight">
                    {experience.title}
                  </DialogTitle>
                  <Badge variant="outline" className="shrink-0 whitespace-nowrap w-fit">
                    {experience.date}
                  </Badge>
                </div>
                <DialogDescription className="text-base flex flex-col gap-1">
                  <span className="font-semibold text-primary">{experience.role}</span>
                  {experience.organization && (
                    <span className="text-muted-foreground">{experience.organization}</span>
                  )}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <h4 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                  {isTechnicalMode ? 'Technical Implementations & Metrics' : 'Key Responsibilities & Achievements'}
                </h4>
                <ul className="space-y-3">
                  {details.map((detail, index) => (
                    <motion.li 
                      key={index}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 + 0.2 }}
                      className="flex items-start text-foreground/90 leading-relaxed"
                    >
                      <span className="text-primary mr-3 mt-1.5 text-lg leading-none">•</span>
                      <span>{detail}</span>
                    </motion.li>
                  ))}
                </ul>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
};

export default ExperienceModal;