import React from 'react';
import { motion } from 'framer-motion';

const WavePageTransition = ({ children }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15, filter: 'blur(4px)' }}
      animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
      exit={{ opacity: 0, y: -15, filter: 'blur(4px)' }}
      transition={{
        duration: 0.4,
        ease: [0.45, 0, 0.55, 1], // Sine-like easeInOut
      }}
      className="w-full h-full"
    >
      {children}
    </motion.div>
  );
};

export default WavePageTransition;