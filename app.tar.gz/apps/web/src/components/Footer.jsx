import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Github, Linkedin, Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';
import FooterMeters from './FooterMeters.jsx';

const Footer = () => {
  const { toast } = useToast();

  const handleSocialClick = (platform) => {
    if (platform === 'LinkedIn') {
      window.open('https://www.linkedin.com/in/dmitri-de-freitas-16a540347/', '_blank');
    } else {
      toast({
        title: `🚧 ${platform} Link`,
        description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
      });
    }
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Projects', path: '/projects' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <footer className="bg-muted/30 border-t border-border mt-auto relative z-10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Name and Tagline */}
          <div>
            <h3 className="text-xl font-bold mb-2">Dmitri De Freitas</h3>
            <p className="text-sm text-muted-foreground">
              Quantitative Finance & Data Science
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-semibold mb-4">Quick Links</h4>
            <nav className="flex flex-col space-y-2">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  {link.name}
                </Link>
              ))}
            </nav>
          </div>

          {/* Social and Resume */}
          <div>
            <h4 className="text-sm font-semibold mb-4">Connect</h4>
            <div className="flex space-x-3 mb-4">
              <motion.div
                animate={{ scale: [1, 1.08, 1], opacity: [0.8, 1, 0.8] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              >
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handleSocialClick('LinkedIn')}
                  className="hover:text-primary"
                >
                  <Linkedin className="h-4 w-4" />
                </Button>
              </motion.div>
              
              <motion.div
                animate={{ scale: [1, 1.08, 1], opacity: [0.8, 1, 0.8] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 1.5 }}
              >
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handleSocialClick('GitHub')}
                  className="hover:text-primary group"
                >
                  <Github className="h-4 w-4 group-hover:rotate-12 transition-transform" />
                </Button>
              </motion.div>
            </div>
            <Button
              asChild
              variant="outline"
              size="sm"
              className="w-full md:w-auto"
            >
              <a href="https://drive.google.com/file/d/1Ff9CtgP3OndC67ARXolrRjH6Y2seE1Sl/view?usp=drive_link" target="_blank" rel="noopener noreferrer">
                <Download className="mr-2 h-4 w-4" />
                Download Resume
              </a>
            </Button>
          </div>
        </div>

        {/* Copyright and Meters */}
        <div className="pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-center md:text-left text-sm text-muted-foreground">
            © {new Date().getFullYear()} Dmitri De Freitas. All rights reserved.
          </p>
          <FooterMeters />
        </div>
      </div>
    </footer>
  );
};

export default Footer;