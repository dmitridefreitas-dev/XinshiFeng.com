import React from 'react';
import { motion } from 'framer-motion';

const FinanceTicker = () => {
  const terms = [
    "Algorithmic Trading & Market Microstructure",
    "Derivatives Pricing & Volatility Modeling",
    "Portfolio Optimization & Risk Management",
    "Stochastic Calculus & Interest Rate Modeling",
    "High-Frequency Trading Systems",
    "Backtesting & Execution Algorithms",
    "Data Science & Machine Learning",
    "Predictive Modeling & Statistical Inference",
    "Time Series Analysis & Forecasting",
    "Model Validation & Hypothesis Testing",
    "Feature Engineering & Ensemble Methods",
    "Data Pipeline Development & ETL Automation",
    "Real-Time Data Processing & Streaming",
    "Database Design & Big Data Solutions",
    "Cloud Infrastructure & Scalable Systems"
  ];

  // Duplicate terms to create a seamless loop
  const tickerItems = [...terms, ...terms, ...terms];

  return (
    <div className="w-full bg-muted/50 border-y border-border overflow-hidden py-2.5 flex items-center">
      <motion.div
        className="flex whitespace-nowrap"
        animate={{ x: [0, -3000] }} // Adjusted width for longer terms
        transition={{
          repeat: Infinity,
          ease: "linear",
          duration: 60, // Slower duration for longer text
        }}
      >
        {tickerItems.map((term, index) => (
          <div key={index} className="flex items-center mx-6">
            <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">
              {term}
            </span>
            <span className="mx-6 text-primary/40 text-xs">•</span>
          </div>
        ))}
      </motion.div>
    </div>
  );
};

export default FinanceTicker;